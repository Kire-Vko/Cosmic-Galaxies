﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cosmic_Galaxies
{
    class Moon
    {
        public string name;
        public string planet;
        //constructor
        public Moon() { }
        //Methods\
        public static bool chackMoon(string userInput,Planet[] planetsList, int planetCount)
        {
            string[] inputList = userInput.Split(" ");
            string[] openBracketSplit = userInput.Split("[");
            string[] closeBracketSplit = userInput.Split("]");
            string[] bracketSplit = openBracketSplit[1].Split("]");
            bool planetExist = false;

            //Chack if valid planet name format 
            if (inputList[2].StartsWith('[') && openBracketSplit[1].Substring(openBracketSplit[1].Length - 2, 1) == "]")
            {

                //Chack if valid moon name format
                if (closeBracketSplit[1].Substring(1, 1) == "[" && inputList[inputList.Length - 1].EndsWith("]"))
                {

                    //Chack if there exist the galaxy given by the user
                    for (int i = 0; i < planetCount - 1; i++)
                    {
                        if (bracketSplit[0] == planetsList[i].name)
                        {

                            planetsList[i].moons++;
                            planetExist = true;
                        }

                    }
                    if (planetExist)
                    {
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("The planet did not exist!!!");
                        return false;
                    }

                }
                else
                {
                    Console.WriteLine("Invalid moon name format!!! Pleace enter the name with brackeds [Moon name]");
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Invalid Planet name format!!! Pleace enter the name with brackeds [Planet name]");
                return false;

            }
        }
        public void printMoon()
        {
            Console.WriteLine($"{name} is from planet {planet}");
        }
    }
}