﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cosmic_Galaxies
{
    class Galaxy
    {
        //
        public string name;
        public string type;
        public double age;
        public string agePercise;
        public int stars;
        // Constructors
        public Galaxy()
        {
     
        }
        //Methods
        public static bool chekInput(string userInput)
        {
            string[] inputList = userInput.Split(" ");
            string[] openBracketSplit = userInput.Split("[");
            string[] bracketSplit = openBracketSplit[1].Split("]");

            string[] propertisSplit = bracketSplit[1].Split(" ");
            //Chack if valid name format 
            if (inputList[2].StartsWith("[") && inputList[inputList.Length - 3].EndsWith("]"))
            {
                //Chack if valid type or return the user to reenter new input
                if (inputList[inputList.Length - 2] == "elliptical" || inputList[inputList.Length - 2] == "lenticular" || inputList[inputList.Length - 2] == "spiral" || inputList[inputList.Length - 2] == "irregular")
                {
                    //Chack if valid age format or return the user to reenter new input
                    if (inputList[inputList.Length - 1].EndsWith("M") || inputList[inputList.Length - 1].EndsWith("B"))
                    {
                        //SAVE GALAXY DATA AND CREATE OBJECT
                        return true;

                    }
                    else
                    {
                        Console.Write("Invalid age format!!!! Pleace enter age with following char of:" +
                            "(M) - Million" +
                            "(B) - Billion");
                        return false;

                    }
                }
                else
                {
                    Console.Write("Invalid type!!! Pleace enter one of those: " +
                        " elliptical" +
                        " lenticular" +
                        " spiral" +
                        " irregular");
                    return false;

                }
            }
            else
            {
                Console.WriteLine("Invalid name format!!! Pleace enter the name with brackeds [Galaxy name]");
                return false;
            }
        }

        public void PublishGalaxy()
        {
            Console.WriteLine($"{name} is type of {type} and its {age}{agePercise} years old.");
        }

    }
}