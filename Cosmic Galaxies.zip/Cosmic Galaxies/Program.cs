﻿using System;

namespace Cosmic_Galaxies
{
    class Program
    {
        static void Main(string[] args)
        {

            string userInput = "";
            int galaxyCount = 1;
            Galaxy[] galaxyList = new Galaxy[galaxyCount];
            int starsCount = 1;
            Stars[] starsList = new Stars[starsCount];
            int planetsCount = 1;
            Planet[] planetsList = new Planet[planetsCount];
            int moonCount = 1;
            Moon[] moonsList = new Moon[moonCount];

            while (userInput != "exit")
            {
                userInput = Console.ReadLine();
                string[] inputList = userInput.Split(" ");

                Array.Resize(ref galaxyList, galaxyCount);
                Array.Resize(ref starsList, starsCount);
                Array.Resize(ref planetsList, planetsCount);
                Array.Resize(ref moonsList, moonCount);

                
                if (inputList[0] == "add")
                {
                    string[] openBracketSplit = userInput.Split("[");
                    string[] bracketSplit = openBracketSplit[1].Split("]");
                    string[] propertisSplit = bracketSplit[1].Split(" ");
                    //---------------------Add a galaxy---------------------------
                    if (inputList[1] == "galaxy")
                    {

                        if (Galaxy.chekInput(userInput))
                        {
                            galaxyList[galaxyCount - 1] = new Galaxy();
                            galaxyList[galaxyCount - 1].name = bracketSplit[0];
                            galaxyList[galaxyCount - 1].type = inputList[inputList.Length - 2];
                            galaxyList[galaxyCount - 1].age = double.Parse(inputList[inputList.Length - 1].Substring(0, inputList[inputList.Length - 1].Length - 1));
                            galaxyList[galaxyCount - 1].agePercise = inputList[inputList.Length - 1].Substring(inputList[inputList.Length - 1].Length - 1, 1);

                            galaxyList[galaxyCount - 1].PublishGalaxy();

                            galaxyCount++;
                        }
                    }

                    //---------------------Add a star-----------------------
                    else if (inputList[1] == "star")
                    {

                        string[] secondBracketSplit = openBracketSplit[2].Split("]");
                        string[] secondPropertisSplit = secondBracketSplit[1].Split(" ");

                        if (Stars.CheckStar(userInput, galaxyList, galaxyCount))
                        {
                            starsList[starsCount - 1] = new Stars();
                            starsList[starsCount - 1].galaxy = bracketSplit[0];
                            starsList[starsCount - 1].name = secondBracketSplit[0];
                            starsList[starsCount - 1].mass = double.Parse(inputList[inputList.Length - 4]);
                            starsList[starsCount - 1].size = double.Parse(inputList[inputList.Length - 3]);
                            starsList[starsCount - 1].temp = int.Parse(inputList[inputList.Length - 2]);
                            starsList[starsCount - 1].brightnes = double.Parse(inputList[inputList.Length - 1]);

                            starsList[starsCount - 1].PrintStar();
                            starsCount++;
                        }

                    }

                    //------------------Add planet-------------------------
                    else if (inputList[1] == "planet")
                    {
                        string[] secondBracketSplit = openBracketSplit[2].Split("]");
                        string[] secondPropertisSplit = secondBracketSplit[1].Split(" ");
                        if (Planet.checkPlanet(userInput ,starsList, starsCount))
                        {
                            planetsList[planetsCount - 1] = new Planet();
                            planetsList[planetsCount - 1].star = bracketSplit[0];
                            planetsList[planetsCount - 1].name = secondBracketSplit[0];
                            if (inputList[inputList.Length - 3].EndsWith("]"))
                            {
                                planetsList[planetsCount - 1].type = inputList[inputList.Length - 2];
                            }
                                
                            else
                            {
                                planetsList[planetsCount - 1].type = inputList[inputList.Length - 3] + " " + inputList[inputList.Length - 2];
                                
                            }
                                
                            planetsList[planetsCount - 1].isOrbiting = inputList[inputList.Length - 1];

                            planetsList[planetsCount - 1].printPlanet();
                            planetsCount++;
                        }
                    }

                    //----------------Add moon--------------------------
                    else if (inputList[1] == "moon")
                    {
                        string[] secondBracketSplit = openBracketSplit[2].Split("]");
                        string[] secondPropertisSplit = secondBracketSplit[1].Split(" ");
                        if (Moon.chackMoon(userInput, planetsList, planetsCount))
                        {
                            moonsList[moonCount - 1] = new Moon();
                            moonsList[moonCount - 1].planet = bracketSplit[0];
                            moonsList[moonCount - 1].name = secondBracketSplit[0];

                            moonsList[moonCount - 1].printMoon();
                            moonCount++;
                        }
                    }



                }
                //=======================Print stats==============
                else if (inputList[0] == "stats")
                {
                    Console.WriteLine($"---Stats---\n" +
                        $"Galaxies: {galaxyCount - 1}\n" +
                        $"Stars: {starsCount - 1}\n" +
                        $"Planets: {planetsCount - 1}\n" +
                        $"Moons: {moonCount - 1}\n" +
                        $"---End of stats---");
                }
                //=================Print list=============
                else if(inputList[0] == "list")
                {
                    //---------------Galaxies list-----------
                    if(inputList[1] == "galaxies")
                    {
                        Console.WriteLine("---List of all researched galaxies---");
                        for (int currGalaxy = 0; currGalaxy < galaxyCount - 1; currGalaxy++)
                        {
                            Console.WriteLine(galaxyList[currGalaxy].name + "\n");
                        }
                        Console.WriteLine("---End of galaxies list---");
                    }
                    //---------------Stars list-----------
                    else if (inputList[1] == "stars")
                    {
                        Console.WriteLine("---List of all researched stars---");
                        for (int currStar = 0; currStar < starsCount - 1; currStar++)
                        {
                            Console.WriteLine(starsList[currStar].name + "\n");
                        }
                        Console.WriteLine("---End of stars list---");
                    }
                    //---------------Planets list-----------
                    else if (inputList[1] == "planets")
                    {
                        Console.WriteLine("---List of all researched planets---");
                        for (int currPlanet = 0; currPlanet < planetsCount - 1; currPlanet++)
                        {
                            Console.WriteLine(planetsList[currPlanet].name + "\n");
                        }
                        Console.WriteLine("---End of planets list---");
                    }
                    //---------------Moons list-----------
                    else if (inputList[1] == "moons")
                    {
                        Console.WriteLine("---List of all researched moons---");
                        for (int currMoon = 0; currMoon < moonCount - 1; currMoon++)
                        {
                            Console.WriteLine(moonsList[currMoon].name + "\n");
                        }
                        Console.WriteLine("---End of moons list---");
                    }
                }
                else if(inputList[0] == "print")
                {
                    string[] openBracketSplit = userInput.Split("[");
                    string[] bracketSplit = openBracketSplit[1].Split("]");
                    //Get galaxy name
                    string galaxyName = bracketSplit[0];
                    Console.WriteLine(galaxyName);

                    bool galaxyExist = false;
                    int galaxyPosition = -1;
                    //Loop in galaxies list to find if galaxy exist
                    for (int currGalaxy = 0; currGalaxy < galaxyCount - 1; currGalaxy++)
                    {
                        if (galaxyName == galaxyList[currGalaxy].name)
                        {
                            galaxyExist = true;
                            galaxyPosition = currGalaxy;
                        }
                    }

                    //Loop in stars and see if they are in the current galaxy
                    bool hasStar = false;
                    int existingStars = 1;
                    int[] starPosition = new int[existingStars];
                    for (int currStar = 0; currStar < starsCount - 1; currStar++)
                    {
                        if (starsList[currStar].galaxy == galaxyList[galaxyPosition].name)
                        {
                            hasStar = true;
                            starPosition[starPosition.Length - 1] = currStar;
                            existingStars++;
                            Array.Resize(ref starPosition, existingStars);
                        }
                    }
                    //Loop in planets and see ifm they are in the cuttent galaxy
                    bool hasPlanet = false;
                    int existingPlanets = 1;
                    int[] planetPosition = new int[existingPlanets];
                    for (int i = 0; i < existingStars - 1; i++)
                    {
                        for (int currPlanet = 0; currPlanet < planetsCount - 1; currPlanet++)
                        {
                            if (planetsList[currPlanet].star == starsList[starPosition[i]].name)
                            {
                                hasPlanet = true;
                                planetPosition[planetPosition.Length - 1] = currPlanet;
                                existingPlanets++;
                                Array.Resize(ref planetPosition, existingPlanets);
                            }
                        }
                    }
                    //Loop in moons and see ifm they are in the cuttent galaxy
                    bool hasMoon = false;
                    int existingMoons = 1;
                    int[] moonPosition = new int[existingMoons];
                    for (int i = 0; i < existingPlanets - 1; i++)
                    {
                        for (int currMoon = 0; currMoon < moonCount - 1; currMoon++)
                        {
                            if (moonsList[currMoon].planet == planetsList[planetPosition[i]].name)
                            {
                                hasMoon = true;
                                moonPosition[moonPosition.Length - 1] = currMoon;
                                existingMoons++;
                                Array.Resize(ref moonPosition, existingMoons);
                            }
                        }
                    }

                    if (galaxyExist)
                    {
                        Console.WriteLine($"---Data for {galaxyName} galaxy---\n" +
                            $"Type: {galaxyList[galaxyPosition].type}\n" +
                            $"Age: {galaxyList[galaxyPosition].age}{galaxyList[galaxyPosition].agePercise}\n" +
                            $"Stars:");
                        if (hasStar)
                        {
                            for (int i = 0; i < existingStars - 1; i++)
                            {
                                Console.WriteLine($"-   Name: {starsList[starPosition[i]].name}\n" +
                                $"    Class: {starsList[starPosition[i]].Clas} G({starsList[starPosition[i]].mass}, {starsList[starPosition[i]].size}, {starsList[starPosition[i]].temp}, {starsList[starPosition[i]].brightnes})");
                            }
                            Console.WriteLine("    Planets:");
                            if (hasPlanet)
                            {
                                for (int i = 0; i < existingPlanets - 1; i++)
                                {
                                    Console.WriteLine($"    o    Name: {planetsList[planetPosition[i]].name}\n" +
                                        $"         Type: {planetsList[planetPosition[i]].type}\n" +
                                        $"         Support life: {planetsList[planetPosition[i]].isOrbiting}");
                                }
                                Console.WriteLine("         Moons:");
                                if (hasMoon)
                                {
                                    for (int i = 0; i < existingMoons - 1; i++)
                                    {
                                        Console.WriteLine($"         §   Name: {moonsList[moonPosition[i]].name}");
                                    }
                                }
                                else Console.WriteLine("            There are no moons to this planet");
                            }
                            else Console.WriteLine("        There are no planets in this galaxy");
                        }
                        else Console.WriteLine("    There are no stars in this galaxy");
                    }
                    else Console.WriteLine("The galaxy did not exist");
                }

            }
        }
    }

}