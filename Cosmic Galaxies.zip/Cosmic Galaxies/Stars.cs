﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cosmic_Galaxies
{
    class Stars
    {
        public string name;
        private string clas;
        public double mass;
        public double size;
        public int temp;
        public double brightnes;
        public string galaxy;
        public int planets;
        //Comstructor
        public Stars()
        {
           
        }
        //Properties
        public string Clas
        {
            get { return clas; }
            set
            {
                if (temp >= 30000 && brightnes >= 30000 && mass >= 16 && size >= 6.6) clas = "O";
                else if (temp >= 10000 && brightnes >= 25 && mass >= 2.1 && size >= 1.8) clas = "B";
                else if (temp >= 7500 && brightnes >= 5 && mass >= 1.4 && size >= 1.4) clas = "A";
                else if (temp >= 6000 && brightnes >= 1.5 && mass >= 1.04 && size >= 1.15) clas = "F";
                else if (temp >= 5200 && brightnes >= 0.6 && mass >= 0.8 && size >= 0.96) clas = "G";
                else if (temp >= 3700 && brightnes >= 0.08 && mass >= 0.45 && size >= 0.7) clas = "K";
                else if (temp >= 2400 && brightnes <= 0.08 && mass >= 0.08 && size <= 0.7) clas = "M";
            }
        }

        //Methods
        public static bool CheckStar(string userInput, Galaxy[] galaxyList, int galaxyCount)
        {
            string[] inputList = userInput.Split(" ");
            string[] openBracketSplit = userInput.Split("[");
            string[] closeBracketSplit = userInput.Split("]");
            string[] bracketSplit = openBracketSplit[1].Split("]");
            bool galaxyExist = false;

            //Chack if valid galaxy name format 
            if (inputList[2].StartsWith('[') && openBracketSplit[1].Substring(openBracketSplit[1].Length - 2, 1) == "]")
            {
                //Chack if valid star name format 
                if (closeBracketSplit[1].Substring(1, 1) == "[" && inputList[inputList.Length - 5].EndsWith("]"))
                {
                    //Chack if there is correct number of parrameters given by the user
                    if (inputList[inputList.Length - 5].EndsWith("]"))
                    {

                        //Chack if there exist the galaxy given by the user
                        for (int i = 0; i < galaxyCount - 1; i++)
                        {
                            if (bracketSplit[0] == galaxyList[i].name)
                            {

                                galaxyList[i].stars++;
                                galaxyExist = true;
                            }

                        }
                        if (galaxyExist)
                        {
                            return true;
                        }
                        else
                        {
                            Console.WriteLine("The galaxy did not exist!!!");
                            return false;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid number of parameters!!!");
                        return false;

                    }
                }
                else
                {
                    Console.WriteLine("Invalid star name format!!! Pleace enter the name with brackeds [Star name]");
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Invalid galaxy name format!!! Pleace enter the name with brackeds [Galaxy name]");
                return false;

            }
        }
        public void PrintStar()
        {
            Console.WriteLine($"{name} of {galaxy} galaxy is from class {Clas}({mass},{size},{temp},{brightnes})");
        }
    }
}