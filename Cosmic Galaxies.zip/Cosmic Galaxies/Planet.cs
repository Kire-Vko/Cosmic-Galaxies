﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cosmic_Galaxies
{
    class Planet
    {
        public string name;
        public string type;
        public string isOrbiting;
        public string star;
        public int moons;
        //constructor
        public Planet()
        {
           
        }
        //methods
        public static bool checkPlanet(string userInput, Stars[] starsList, int starsCount)
        {
            string[] inputList = userInput.Split(" ");
            string[] openBracketSplit = userInput.Split("[");
            string[] closeBracketSplit = userInput.Split("]");
            string[] bracketSplit = openBracketSplit[1].Split("]");
            string[] secondBracketSplit = openBracketSplit[2].Split("]");
            string[] propertisSplit = bracketSplit[1].Split(" ");
            string[] secondPropertisSplit = secondBracketSplit[1].Split(" ");
            bool starExist = false;

            //Chack if valid star name format 
            if (inputList[2].StartsWith('[') && openBracketSplit[1].Substring(openBracketSplit[1].Length - 2, 1) == "]")
            {
                //Chack if valid isOrbiting parametar
                if (inputList[inputList.Length - 1] == "yes" || inputList[inputList.Length - 1] == "no")
                {
                    //Chack if there exist the galaxy given by the user
                    for (int i = 0; i < starsCount - 1; i++)
                    {
                        if (bracketSplit[0] == starsList[i].name)
                        {
                            starsList[i].planets++;
                            starExist = true;
                        }

                    }
                    if (starExist)
                    {
                        if (inputList[inputList.Length - 3].EndsWith("]"))
                        {
                            //Chack type name 
                            if (inputList[inputList.Length - 2] == "terrestrial"
                                || inputList[inputList.Length - 2] == "mesoplanet"
                                || inputList[inputList.Length - 2] == "mini-neptune"
                                || inputList[inputList.Length - 2] == "planetar"
                                || inputList[inputList.Length - 2] == "super-earth"
                                || inputList[inputList.Length - 2] == "super-jupiter")
                            {
                                return true;
                            }
                            else
                            {
                                Console.WriteLine("The type of planet is incorect!!!");
                                Console.WriteLine(secondPropertisSplit.Length + secondPropertisSplit[0]);
                                return false;
                            }
                        }
                        else if (inputList[inputList.Length - 4].EndsWith("]"))
                        {
                            if (inputList[inputList.Length - 3] == "giant" || inputList[inputList.Length - 2] == "planet") return true;
                            else if (inputList[inputList.Length - 3] == "ice" || inputList[inputList.Length - 2] == "giant") return true;
                            else return false;
                        }
                        else return false;
                    }
                    else
                    {
                        Console.WriteLine("The star did not exist!!!");
                        return false;
                    }

                }
                else
                {
                    Console.WriteLine("Chose only yes or no for orbiting planet");
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Invalid star name format!!! Pleace enter the name with brackeds [Star name]");
                return false;

            }
        }
        public string getType(string[] parametars)
        {
            if (parametars.Length == 2) return parametars[0];
            else if (parametars.Length == 3) return parametars[0] + parametars[1];
            else return "Invalid type name";
        }

        public void printPlanet()
        {
            Console.WriteLine($"{name} of {star} star is from type {type}. Orbiting: {isOrbiting}");
        }
    }
}